package com.zww149.shoppingmall149.utils;

/**
 * 作用：配置各个页面联网地址
 */
public class Constants {
    public static String HOME_URL = "http://192.168.43.200:8080/atguigu/json/HOME_URL.json";
}
